AnchorCut - raw outputs from the full 50-episode run (run id 20261120-190914-duke)
Kuku AI Generalist Assignment, Problem 1. Unedited: nothing in raw_outputs/ was changed by hand.

raw_outputs/   Every LLM call exactly as made: prompt, raw model response, model name, time,
               and parse error if any. One file per attempt (80 calls: 51 anchor tagging, 29 critic).
anchors/       Per episode: the model's anchor sheet as returned, plus which anchors code accepted
               and which it dropped (with the reason, e.g. quote not found in the screenplay).
critic/        Per candidate promo: the cold-viewer critic's verdict as returned and the model used.
               (3 verdicts belong to windows that were later replaced when episodes 46-47 were
               re-tagged after a pause; they are kept because they are real outputs.)
candidates.json  The 112 windows built by code from the anchors, with selection statistics.
results/       What code derived from the model outputs:
                 posting_schedule.csv  ranked promos: tier, segments (episode + start/end), hook,
                                       cliffhanger, why it works, scores, issues
                 promos.json           the same with full transcripts and critic reasoning
                 quality_report.md     coverage, tier counts, where the tool picks badly
status.json, run.log  Progress, model chain, errors and fallback events for the run.

Models: gemini-3.5-flash (episodes 1-14, 16, 46) and gemini-3.5-flash-lite (the other 34 episodes
and all critic calls) after flash hit its daily free-tier quota.
Tier rule: final results use the v2 Tier 3 rule described in the README / solution doc.
The input screenplays are not included.
